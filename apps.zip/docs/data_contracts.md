# Data Contracts

Define required inputs and outputs for each month.
