# Dispute-Proof Mode

Rules for NEEDS_REVIEW gating and validation failures.
