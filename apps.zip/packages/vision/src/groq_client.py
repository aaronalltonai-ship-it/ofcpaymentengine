def get_client():
    raise NotImplementedError("groq client not wired")
