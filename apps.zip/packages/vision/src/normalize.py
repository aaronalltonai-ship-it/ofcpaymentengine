def normalize_currency(value: str) -> float:
    return float(value.replace(",", ""))
