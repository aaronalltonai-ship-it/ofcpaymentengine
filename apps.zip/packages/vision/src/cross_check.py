def cross_check_outputs():
    raise NotImplementedError("cross-check not wired")
