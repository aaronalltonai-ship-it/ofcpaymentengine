def extract_two_pass():
    raise NotImplementedError("two-pass extraction not wired")
