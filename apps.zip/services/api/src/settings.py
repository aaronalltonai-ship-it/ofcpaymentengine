from dataclasses import dataclass
import os


def _float_env(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return float(default)
    try:
        return float(raw)
    except ValueError:
        return float(default)


@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "")
    groq_api_key: str = os.getenv("GROQ_API_KEY", "")
    groq_model_primary: str = os.getenv(
        "GROQ_MODEL_PRIMARY",
        "meta-llama/llama-4-maverick-17b-128e-instruct",
    )
    groq_model_secondary: str = os.getenv(
        "GROQ_MODEL_SECONDARY",
        "meta-llama/llama-4-scout-17b-16e-instruct",
    )
    groq_temperature_pass1: float = _float_env("GROQ_TEMPERATURE_PASS1", 0.0)
    groq_temperature_pass2: float = _float_env("GROQ_TEMPERATURE_PASS2", 0.0)
    groq_temperature_secondary: float = _float_env("GROQ_TEMPERATURE_SECONDARY", 0.0)
    groq_timeout_seconds: int = int(os.getenv("GROQ_TIMEOUT_SECONDS", "60"))
    storage_backend: str = os.getenv("STORAGE_BACKEND", "local")
    storage_local_root: str = os.getenv("STORAGE_LOCAL_ROOT", "data/uploads")
    s3_endpoint: str = os.getenv("S3_ENDPOINT", "")
    s3_bucket: str = os.getenv("S3_BUCKET", "")
    s3_access_key: str = os.getenv("S3_ACCESS_KEY", "")
    s3_secret_key: str = os.getenv("S3_SECRET_KEY", "")
    s3_region: str = os.getenv("S3_REGION", "us-east-1")
    cors_origins: list[str] = [
        origin.strip()
        for origin in os.getenv("CORS_ORIGINS", "").split(",")
        if origin.strip()
    ]
    invoice_issuer_name: str = os.getenv("INVOICE_ISSUER_NAME", "Payout Engine")
    invoice_issuer_email: str = os.getenv("INVOICE_ISSUER_EMAIL", "")
    invoice_issuer_address: str = os.getenv("INVOICE_ISSUER_ADDRESS", "")
    invoice_payment_terms: str = os.getenv("INVOICE_PAYMENT_TERMS", "Net 7")
    invoice_currency: str = os.getenv("INVOICE_CURRENCY", "USD")
    invoice_number_prefix: str = os.getenv("INVOICE_NUMBER_PREFIX", "INV")


settings = Settings()
