from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel

from db.repositories import create_upload, list_uploads, new_upload_record
from services.storage import get_object_store

router = APIRouter()

MAX_UPLOAD_BYTES = 20 * 1024 * 1024


class UploadResponse(BaseModel):
    upload_id: str
    filename: str
    content_type: str
    size_bytes: int
    sha256: str
    storage_path: str


class UploadListResponse(BaseModel):
    uploads: list[UploadResponse]


@router.post("/uploads", response_model=UploadResponse)
async def upload_screenshot(file: UploadFile = File(...)) -> UploadResponse:
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Empty upload")
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=400, detail="Upload exceeds 20MB limit")

    store = get_object_store()
    stored = store.save(file.filename, content, file.content_type or "application/octet-stream")
    record = new_upload_record(
        source="screenshot",
        filename=file.filename,
        content_type=stored.content_type,
        size_bytes=stored.size_bytes,
        sha256=stored.sha256,
        storage_path=stored.url,
    )
    saved = create_upload(record)
    return UploadResponse(**saved.__dict__)


@router.get("/uploads", response_model=UploadListResponse)
def list_uploads_endpoint() -> UploadListResponse:
    uploads = [UploadResponse(**item.__dict__) for item in list_uploads()]
    return UploadListResponse(uploads=uploads)
