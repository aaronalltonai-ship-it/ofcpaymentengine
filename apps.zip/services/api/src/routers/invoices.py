from decimal import Decimal
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, RedirectResponse
from pydantic import BaseModel

from db.repositories import get_invoice, get_payout_run, list_invoices
from services.invoices import generate_invoices_for_run

router = APIRouter()


class InvoiceResponse(BaseModel):
    invoice_id: str
    run_id: str
    month: str
    recipient_type: str
    recipient_id: str
    invoice_number: str
    status: str
    file_format: str
    filename: str
    content_type: str
    storage_path: str
    size_bytes: int
    sha256: str
    total_usd: Decimal
    download_url: str


class InvoiceListResponse(BaseModel):
    invoices: list[InvoiceResponse]


def _to_response(record) -> InvoiceResponse:
    return InvoiceResponse(
        invoice_id=record.invoice_id,
        run_id=record.run_id,
        month=record.month,
        recipient_type=record.recipient_type,
        recipient_id=record.recipient_id,
        invoice_number=record.invoice_number,
        status=record.status,
        file_format=record.file_format,
        filename=record.filename,
        content_type=record.content_type,
        storage_path=record.storage_path,
        size_bytes=record.size_bytes,
        sha256=record.sha256,
        total_usd=record.total_usd,
        download_url=f"/invoices/{record.invoice_id}/download",
    )


@router.get("/invoices", response_model=InvoiceListResponse)
def list_invoices_endpoint(run_id: str | None = None, limit: int = 200) -> InvoiceListResponse:
    records = list_invoices(run_id=run_id, limit=limit)
    return InvoiceListResponse(invoices=[_to_response(record) for record in records])


@router.post("/invoices/{run_id}", response_model=InvoiceListResponse)
def generate_invoices(run_id: str, force: bool = False) -> InvoiceListResponse:
    existing = list_invoices(run_id=run_id, limit=500)
    if existing and not force:
        return InvoiceListResponse(invoices=[_to_response(record) for record in existing])

    run = get_payout_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Payout run not found")
    if not run.outputs_json:
        raise HTTPException(status_code=400, detail="Payout run has no outputs")

    created = generate_invoices_for_run(run_id=run.run_id, month=run.month, outputs=run.outputs_json)
    return InvoiceListResponse(invoices=[_to_response(record) for record in created])


@router.get("/invoices/{invoice_id}/download")
def download_invoice(invoice_id: str):
    record = get_invoice(invoice_id)
    if not record:
        raise HTTPException(status_code=404, detail="Invoice not found")

    path = record.storage_path
    if path.startswith("http://") or path.startswith("https://"):
        return RedirectResponse(path)

    file_path = Path(path)
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Invoice file missing")
    return FileResponse(file_path, media_type=record.content_type, filename=record.filename)
