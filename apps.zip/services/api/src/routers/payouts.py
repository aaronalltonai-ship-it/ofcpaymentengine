from dataclasses import asdict, is_dataclass
from decimal import Decimal
from pathlib import Path
import sys
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from db.repositories import (
    PayoutRunRecord,
    create_payout_run,
    get_extraction,
    list_payout_runs,
    new_payout_run,
    update_payout_run,
)
from services.invoices import generate_invoices_for_run
ROOT = Path(__file__).resolve().parents[4]
ENGINE_PATH = ROOT / "packages" / "engine"
if str(ENGINE_PATH) not in sys.path:
    sys.path.insert(0, str(ENGINE_PATH))

from src.calc_totals import run_payout
from src.types import BountyEvent, HostMonthRow, MonthInputs, RecruiterMonthRow

router = APIRouter()


class MonthInputsModel(BaseModel):
    month: str
    actual_agency_commission_usd: Decimal = Field(ge=0)
    total_agency_gross_usd: Decimal = Field(ge=0)
    host_bonus_pool_percent: Decimal = Field(ge=0, le=1)
    recruiter_pool_percent: Decimal = Field(ge=0, le=1)
    sunset_pool_percent: Decimal = Field(ge=0, le=1)
    sunset_pool_active: bool = False


class HostMonthRowModel(BaseModel):
    host_id: str
    recruiter_id: str | None = None
    beans: int = Field(ge=0)
    hours_streamed: Decimal = Field(ge=0)
    tier: str
    tier_base_pay_usd: Decimal = Field(ge=0)
    eligible_for_bonus: bool
    hit_tier_this_month: bool
    host_active_months: int = Field(ge=0)


class RecruiterMonthRowModel(BaseModel):
    recruiter_id: str
    active_hosts_count: int = Field(ge=0)
    new_qualifying_host_this_month: bool
    legacy_recruiter: bool = False


class BountyEventModel(BaseModel):
    event_id: str
    month: str
    host_id: str
    recruiter_id: str
    milestone_code: str
    amount_usd: Decimal = Field(ge=0)
    note: str | None = None


class PayoutRunRequest(BaseModel):
    extraction_id: str | None = None
    inputs: MonthInputsModel
    hosts: list[HostMonthRowModel]
    recruiters: list[RecruiterMonthRowModel]
    bounty_events: list[BountyEventModel] = []
    rounding: bool = True
    tolerance_usd: Decimal = Decimal("0.01")


class PayoutRunResponse(BaseModel):
    run_id: str
    month: str
    status: str
    extraction_id: str | None
    outputs_json: dict | None
    audit_json: dict | None


class PayoutRunListResponse(BaseModel):
    runs: list[PayoutRunResponse]


def _model_dump(model: BaseModel) -> dict:
    if hasattr(model, "model_dump"):
        return model.model_dump()
    return model.dict()


def _serialize(value: Any) -> Any:
    if is_dataclass(value):
        return _serialize(asdict(value))
    if isinstance(value, Decimal):
        return f"{value:.2f}"
    if isinstance(value, list):
        return [_serialize(item) for item in value]
    if isinstance(value, dict):
        return {key: _serialize(val) for key, val in value.items()}
    return value


@router.post("/run")
def run_payouts(payload: PayoutRunRequest) -> dict:
    if payload.extraction_id:
        extraction = get_extraction(payload.extraction_id)
        if not extraction or not extraction.normalized_json:
            raise HTTPException(status_code=404, detail="Extraction not found")
        normalized = extraction.normalized_json
        inputs = MonthInputs(**normalized)
        hosts = [HostMonthRow(**row) for row in normalized.get("hosts", [])]
        recruiters = [RecruiterMonthRow(**row) for row in normalized.get("recruiters", [])]
        bounty_events = [BountyEvent(**row) for row in normalized.get("bounty_events", [])]
    else:
        inputs = MonthInputs(**_model_dump(payload.inputs))
        hosts = [HostMonthRow(**_model_dump(row)) for row in payload.hosts]
        recruiters = [RecruiterMonthRow(**_model_dump(row)) for row in payload.recruiters]
        bounty_events = [BountyEvent(**_model_dump(row)) for row in payload.bounty_events]

    if payload.extraction_id:
        inputs_json = _serialize(
            {
                "inputs": normalized,
                "hosts": normalized.get("hosts", []),
                "recruiters": normalized.get("recruiters", []),
                "bounty_events": normalized.get("bounty_events", []),
            }
        )
    else:
        inputs_json = _serialize(
            {
                "inputs": _model_dump(payload.inputs),
                "hosts": [_model_dump(row) for row in payload.hosts],
                "recruiters": [_model_dump(row) for row in payload.recruiters],
                "bounty_events": [_model_dump(row) for row in payload.bounty_events],
            }
        )

    run_record = new_payout_run(
        month=inputs.month,
        status="PENDING",
        inputs_json=inputs_json,
        extraction_id=payload.extraction_id,
    )
    saved_run = create_payout_run(run_record)

    result = run_payout(
        inputs,
        hosts,
        recruiters,
        bounty_events,
        rounding=payload.rounding,
        tolerance=payload.tolerance_usd,
    )

    outputs_json = _serialize(
        {
            "host_payouts": [asdict(p) for p in result.host_payouts],
            "recruiter_payouts": [asdict(p) for p in result.recruiter_payouts],
        }
    )
    updated_run = update_payout_run(
        PayoutRunRecord(
            run_id=saved_run.run_id,
            month=saved_run.month,
            extraction_id=saved_run.extraction_id,
            status="COMPLETED",
            inputs_json=saved_run.inputs_json,
            outputs_json=outputs_json,
            audit_json=_serialize(result.audit),
        )
    )

    response = _serialize(result)
    response["run_id"] = updated_run.run_id
    invoice_errors: list[str] = []
    try:
        created = generate_invoices_for_run(
            run_id=updated_run.run_id,
            month=updated_run.month,
            outputs=outputs_json,
        )
        response["invoices_created"] = len(created)
    except Exception as exc:
        invoice_errors.append(str(exc))
    if invoice_errors:
        response["invoice_errors"] = invoice_errors
    return response


@router.get("/runs", response_model=PayoutRunListResponse)
def list_runs() -> PayoutRunListResponse:
    runs = []
    for run in list_payout_runs():
        runs.append(
            PayoutRunResponse(
                run_id=run.run_id,
                month=run.month,
                status=run.status,
                extraction_id=run.extraction_id,
                outputs_json=run.outputs_json,
                audit_json=run.audit_json,
            )
        )
    return PayoutRunListResponse(runs=runs)
