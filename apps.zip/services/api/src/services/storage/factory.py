from settings import settings

from .local_fs import LocalFileStore
from .object_store import ObjectStore
from .s3_store import S3Config, S3Store


def get_object_store() -> ObjectStore:
    backend = settings.storage_backend.lower()
    if backend == "s3":
        config = S3Config(
            endpoint=settings.s3_endpoint,
            bucket=settings.s3_bucket,
            access_key=settings.s3_access_key,
            secret_key=settings.s3_secret_key,
            region=settings.s3_region,
        )
        return S3Store(config)
    return LocalFileStore(settings.storage_local_root)
