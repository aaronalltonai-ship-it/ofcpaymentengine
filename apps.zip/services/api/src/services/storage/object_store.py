from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class StoredObject:
    key: str
    url: str
    size_bytes: int
    sha256: str
    content_type: str


class ObjectStore(Protocol):
    def save(self, filename: str, content: bytes, content_type: str) -> StoredObject:
        raise NotImplementedError
