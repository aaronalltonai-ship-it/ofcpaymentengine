from pathlib import Path
from uuid import uuid4

from .object_store import StoredObject
from .utils import sha256_bytes


class LocalFileStore:
    def __init__(self, root: str) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, filename: str, content: bytes, content_type: str) -> StoredObject:
        digest = sha256_bytes(content)
        safe_name = filename.replace(" ", "_")
        key = f"{digest}_{uuid4().hex}_{safe_name}"
        path = self.root / key
        path.write_bytes(content)
        return StoredObject(
            key=key,
            url=str(path),
            size_bytes=len(content),
            sha256=digest,
            content_type=content_type,
        )
