from dataclasses import dataclass

import boto3

from .object_store import StoredObject
from .utils import sha256_bytes


@dataclass(frozen=True)
class S3Config:
    endpoint: str
    bucket: str
    access_key: str
    secret_key: str
    region: str


class S3Store:
    def __init__(self, config: S3Config) -> None:
        self.config = config
        self.client = boto3.client(
            "s3",
            endpoint_url=config.endpoint or None,
            aws_access_key_id=config.access_key or None,
            aws_secret_access_key=config.secret_key or None,
            region_name=config.region or None,
        )

    def save(self, filename: str, content: bytes, content_type: str) -> StoredObject:
        digest = sha256_bytes(content)
        key = f"uploads/{digest}/{filename}"
        self.client.put_object(
            Bucket=self.config.bucket,
            Key=key,
            Body=content,
            ContentType=content_type,
        )
        url = f"{self.config.endpoint.rstrip('/')}/{self.config.bucket}/{key}"
        return StoredObject(
            key=key,
            url=url,
            size_bytes=len(content),
            sha256=digest,
            content_type=content_type,
        )
