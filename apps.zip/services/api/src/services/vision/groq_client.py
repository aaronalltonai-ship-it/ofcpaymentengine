import base64
from typing import Any

import httpx

from settings import settings


GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"


def _encode_image(image_bytes: bytes) -> str:
    encoded = base64.b64encode(image_bytes).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def build_message(
    *,
    system_prompt: str,
    user_prompt: str,
    images: list[bytes],
) -> list[dict[str, Any]]:
    content = [{"type": "text", "text": user_prompt}]
    for image in images:
        content.append({"type": "image_url", "image_url": {"url": _encode_image(image)}})
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": content},
    ]


def chat_completion(
    *,
    model: str,
    messages: list[dict[str, Any]],
    response_format: dict | None = None,
    temperature: float = 0.0,
    max_tokens: int = 1024,
) -> str:
    if not settings.groq_api_key:
        raise RuntimeError("GROQ_API_KEY is required")
    headers = {"Authorization": f"Bearer {settings.groq_api_key}"}
    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if response_format:
        payload["response_format"] = response_format
    with httpx.Client(timeout=settings.groq_timeout_seconds) as client:
        response = client.post(GROQ_URL, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]
