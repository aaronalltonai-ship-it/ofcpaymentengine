from pathlib import Path
import json


def load_payment_schema() -> dict:
    root = Path(__file__).resolve().parents[5]
    path = root / "packages" / "vision" / "src" / "schemas" / "payment_receipt.schema.json"
    return json.loads(path.read_text(encoding="ascii"))
