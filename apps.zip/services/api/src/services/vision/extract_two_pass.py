from dataclasses import dataclass
import json
from pathlib import Path

from settings import settings

from .cross_check import DiffEntry, compare_payloads
from .groq_client import build_message, chat_completion
from .normalize import normalize_payload
from .schemas import load_payment_schema
from .validate import validate_image_constraints, validate_limits, validate_schema


@dataclass(frozen=True)
class ExtractionResult:
    status: str
    verbatim: str
    payload: dict | None
    normalized: dict | None
    diffs: list[DiffEntry]
    errors: list[str]


def _load_prompt(name: str) -> str:
    root = Path(__file__).resolve().parents[5]
    path = root / "packages" / "vision" / "src" / "prompts" / name
    return path.read_text(encoding="ascii")


def run_two_pass_extraction(images: list[bytes]) -> ExtractionResult:
    if not images:
        return ExtractionResult(
            status="FAILED",
            verbatim="",
            payload=None,
            normalized=None,
            diffs=[],
            errors=["No images provided"],
        )

    constraints = validate_image_constraints(images[0])
    if constraints.errors:
        return ExtractionResult(
            status="FAILED",
            verbatim="",
            payload=None,
            normalized=None,
            diffs=[],
            errors=constraints.errors,
        )

    pass1_prompt = _load_prompt("pass1_read_verbatim.txt")
    pass2_prompt = _load_prompt("pass2_parse_json.txt")

    system_prompt = (
        "You are a meticulous transcription assistant. Never infer missing values."
    )
    pass1_messages = build_message(
        system_prompt=system_prompt,
        user_prompt=pass1_prompt,
        images=images,
    )
    verbatim = chat_completion(
        model=settings.groq_model_primary,
        messages=pass1_messages,
        temperature=settings.groq_temperature_pass1,
        max_tokens=2048,
    )

    schema = load_payment_schema()
    response_format = {
        "type": "json_schema",
        "json_schema": {
            "name": "payment_extract",
            "schema": schema,
        },
    }
    pass2_messages = build_message(
        system_prompt="You are a strict JSON serializer. Return valid JSON only.",
        user_prompt=f"{pass2_prompt}\n\nVerbatim:\n{verbatim}",
        images=images,
    )
    parsed = chat_completion(
        model=settings.groq_model_primary,
        messages=pass2_messages,
        response_format=response_format,
        temperature=settings.groq_temperature_pass2,
        max_tokens=2048,
    )

    try:
        payload = json.loads(parsed)
    except json.JSONDecodeError as exc:
        return ExtractionResult(
            status="FAILED",
            verbatim=verbatim,
            payload=None,
            normalized=None,
            diffs=[],
            errors=[f"Invalid JSON output: {exc}"],
        )

    normalized = normalize_payload(payload)
    errors = validate_schema(payload).errors + validate_limits(normalized).errors

    return ExtractionResult(
        status="COMPLETED" if not errors else "NEEDS_REVIEW",
        verbatim=verbatim,
        payload=payload,
        normalized=normalized,
        diffs=[],
        errors=errors,
    )


def run_dual_model_extraction(images: list[bytes]) -> ExtractionResult:
    primary = run_two_pass_extraction(images)
    if primary.payload is None:
        return primary

    pass2_prompt = _load_prompt("pass2_parse_json.txt")
    schema = load_payment_schema()
    response_format = {
        "type": "json_schema",
        "json_schema": {
            "name": "payment_extract",
            "schema": schema,
        },
    }
    secondary_messages = build_message(
        system_prompt="You are a strict JSON serializer. Return valid JSON only.",
        user_prompt=pass2_prompt,
        images=images,
    )
    secondary_raw = chat_completion(
        model=settings.groq_model_secondary,
        messages=secondary_messages,
        response_format=response_format,
        temperature=settings.groq_temperature_secondary,
        max_tokens=2048,
    )
    try:
        secondary_payload = json.loads(secondary_raw)
    except json.JSONDecodeError:
        secondary_payload = {}

    diffs = compare_payloads(primary.payload, secondary_payload)
    status = primary.status
    errors = list(primary.errors)
    if diffs:
        status = "NEEDS_REVIEW"
        errors.append("Primary/secondary model mismatch")

    return ExtractionResult(
        status=status,
        verbatim=primary.verbatim,
        payload=primary.payload,
        normalized=primary.normalized,
        diffs=diffs,
        errors=errors,
    )
