from decimal import Decimal


def _parse_number(value):
    if value is None:
        return None
    if isinstance(value, (int, float, Decimal)):
        return Decimal(str(value))
    text = str(value).strip()
    if not text:
        return None
    percent = text.endswith("%")
    if percent:
        text = text[:-1]
    text = text.replace(",", "")
    number = Decimal(text)
    if percent:
        return number / Decimal("100")
    return number


def normalize_payload(payload: dict) -> dict:
    normalized = dict(payload)
    normalized["actual_agency_commission_usd"] = float(
        _parse_number(payload.get("actual_agency_commission_usd") or 0)
    )
    normalized["total_agency_gross_usd"] = float(
        _parse_number(payload.get("total_agency_gross_usd") or 0)
    )
    normalized["host_bonus_pool_percent"] = float(
        _parse_number(payload.get("host_bonus_pool_percent") or 0)
    )
    normalized["recruiter_pool_percent"] = float(
        _parse_number(payload.get("recruiter_pool_percent") or 0)
    )
    normalized["sunset_pool_percent"] = float(
        _parse_number(payload.get("sunset_pool_percent") or 0)
    )

    hosts = []
    for host in payload.get("hosts", []):
        hosts.append(
            {
                "host_id": str(host.get("host_id", "")),
                "recruiter_id": host.get("recruiter_id"),
                "beans": int(_parse_number(host.get("beans") or 0)),
                "hours_streamed": float(_parse_number(host.get("hours_streamed") or 0)),
                "tier": str(host.get("tier", "")),
                "tier_base_pay_usd": float(_parse_number(host.get("tier_base_pay_usd") or 0)),
                "eligible_for_bonus": bool(host.get("eligible_for_bonus")),
                "hit_tier_this_month": bool(host.get("hit_tier_this_month")),
                "host_active_months": int(_parse_number(host.get("host_active_months") or 0)),
            }
        )
    normalized["hosts"] = hosts

    recruiters = []
    for recruiter in payload.get("recruiters", []):
        recruiters.append(
            {
                "recruiter_id": str(recruiter.get("recruiter_id", "")),
                "active_hosts_count": int(_parse_number(recruiter.get("active_hosts_count") or 0)),
                "new_qualifying_host_this_month": bool(
                    recruiter.get("new_qualifying_host_this_month")
                ),
                "legacy_recruiter": bool(recruiter.get("legacy_recruiter")),
            }
        )
    normalized["recruiters"] = recruiters

    bounty_events = []
    for event in payload.get("bounty_events", []):
        bounty_events.append(
            {
                "event_id": str(event.get("event_id", "")),
                "month": str(event.get("month", "")),
                "host_id": str(event.get("host_id", "")),
                "recruiter_id": str(event.get("recruiter_id", "")),
                "milestone_code": str(event.get("milestone_code", "")),
                "amount_usd": float(_parse_number(event.get("amount_usd") or 0)),
                "note": event.get("note"),
            }
        )
    normalized["bounty_events"] = bounty_events

    return normalized
