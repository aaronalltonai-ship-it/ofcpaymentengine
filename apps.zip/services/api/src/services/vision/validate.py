from dataclasses import dataclass
from jsonschema import Draft7Validator

from .schemas import load_payment_schema


@dataclass(frozen=True)
class ValidationResult:
    errors: list[str]


def validate_schema(payload: dict) -> ValidationResult:
    schema = load_payment_schema()
    validator = Draft7Validator(schema)
    errors = [err.message for err in validator.iter_errors(payload)]
    return ValidationResult(errors=errors)


def validate_limits(payload: dict) -> ValidationResult:
    errors: list[str] = []
    if payload.get("actual_agency_commission_usd", 0) < 0:
        errors.append("actual_agency_commission_usd must be >= 0")
    if payload.get("total_agency_gross_usd", 0) < 0:
        errors.append("total_agency_gross_usd must be >= 0")
    for field in [
        "host_bonus_pool_percent",
        "recruiter_pool_percent",
        "sunset_pool_percent",
    ]:
        value = payload.get(field, 0)
        if value < 0 or value > 1:
            errors.append(f"{field} must be between 0 and 1")
    return ValidationResult(errors=errors)


def validate_image_constraints(image_bytes: bytes) -> ValidationResult:
    errors: list[str] = []
    if len(image_bytes) > 4 * 1024 * 1024:
        errors.append("base64 payload exceeds 4MB limit for Groq image input")
    return ValidationResult(errors=errors)
