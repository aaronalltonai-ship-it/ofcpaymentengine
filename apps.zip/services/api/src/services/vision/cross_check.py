from dataclasses import dataclass
from typing import Any


CRITICAL_FIELDS = [
    "month",
    "actual_agency_commission_usd",
    "total_agency_gross_usd",
    "host_bonus_pool_percent",
    "recruiter_pool_percent",
    "sunset_pool_percent",
    "sunset_pool_active",
]


@dataclass(frozen=True)
class DiffEntry:
    path: str
    primary: Any
    secondary: Any


def _compare_value(path: str, primary: Any, secondary: Any, diffs: list[DiffEntry]) -> None:
    if primary != secondary:
        diffs.append(DiffEntry(path=path, primary=primary, secondary=secondary))


def compare_payloads(primary: dict, secondary: dict) -> list[DiffEntry]:
    diffs: list[DiffEntry] = []
    for field in CRITICAL_FIELDS:
        _compare_value(field, primary.get(field), secondary.get(field), diffs)

    primary_hosts = {host.get("host_id"): host for host in primary.get("hosts", [])}
    secondary_hosts = {host.get("host_id"): host for host in secondary.get("hosts", [])}
    host_ids = set(primary_hosts) | set(secondary_hosts)
    for host_id in host_ids:
        left = primary_hosts.get(host_id, {})
        right = secondary_hosts.get(host_id, {})
        _compare_value(f"hosts.{host_id}.beans", left.get("beans"), right.get("beans"), diffs)
        _compare_value(
            f"hosts.{host_id}.tier_base_pay_usd",
            left.get("tier_base_pay_usd"),
            right.get("tier_base_pay_usd"),
            diffs,
        )
        _compare_value(
            f"hosts.{host_id}.eligible_for_bonus",
            left.get("eligible_for_bonus"),
            right.get("eligible_for_bonus"),
            diffs,
        )

    primary_recruiters = {
        recruiter.get("recruiter_id"): recruiter for recruiter in primary.get("recruiters", [])
    }
    secondary_recruiters = {
        recruiter.get("recruiter_id"): recruiter for recruiter in secondary.get("recruiters", [])
    }
    recruiter_ids = set(primary_recruiters) | set(secondary_recruiters)
    for recruiter_id in recruiter_ids:
        left = primary_recruiters.get(recruiter_id, {})
        right = secondary_recruiters.get(recruiter_id, {})
        _compare_value(
            f"recruiters.{recruiter_id}.active_hosts_count",
            left.get("active_hosts_count"),
            right.get("active_hosts_count"),
            diffs,
        )
        _compare_value(
            f"recruiters.{recruiter_id}.legacy_recruiter",
            left.get("legacy_recruiter"),
            right.get("legacy_recruiter"),
            diffs,
        )

    return diffs
