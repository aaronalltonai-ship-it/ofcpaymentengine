#!/usr/bin/env bash
set -euo pipefail

# TODO: run monthly payout job.
