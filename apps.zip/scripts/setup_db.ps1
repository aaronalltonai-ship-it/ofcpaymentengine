Set-StrictMode -Version Latest

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$schema = Join-Path $root "packages\db\schema.sql"

$psql = Get-Command psql -ErrorAction SilentlyContinue
if ($psql) {
    if (-not $env:DATABASE_URL) {
        Write-Error "DATABASE_URL is not set."
        exit 1
    }
    psql "$env:DATABASE_URL" -f $schema
    exit $LASTEXITCODE
}

$docker = Get-Command docker -ErrorAction SilentlyContinue
if ($docker) {
    Push-Location $root
    docker compose up -d postgres
    Get-Content $schema | docker compose exec -T postgres psql -U postgres -d payout
    $status = $LASTEXITCODE
    Pop-Location
    exit $status
}

Write-Error "psql or docker not found. Install Postgres or Docker, then rerun."
exit 1
