#!/usr/bin/env bash
set -euo pipefail

# TODO: export monthly reports.
