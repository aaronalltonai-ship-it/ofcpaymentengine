## Summary

## Changes

## Testing
- [ ] Not run (explain why)
- [ ] Engine tests (`pytest packages/engine/tests`)
- [ ] UI smoke test

## Notes
