---
name: Feature request
about: Suggest an enhancement
title: "[Feature] "
labels: enhancement
---

## Problem

## Proposed solution

## Alternatives considered

## Additional context
