---
name: Bug report
about: Report a problem with payouts, extraction, or UI
title: "[Bug] "
labels: bug
---

## Summary

## Steps to reproduce
1.
2.

## Expected behavior

## Actual behavior

## Environment
- OS:
- Browser (if UI):
- API version/commit:

## Logs or screenshots
